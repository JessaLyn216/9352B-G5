var request = new XMLHttpRequest();

request.open('GET', 'products.json', true);

request.onload = function () {
	// begin accessing JSON data here
	var data = JSON.parse(this.response);
    
    showProducts(data);
}
request.send();

    function showProducts(data) {
        var x = document.getElementById('here');
        for (var i = 0; i < data.length; i++) {
            var y = document.createElement('h1');
            var z = document.createElement('h5');
            var v = document.createElement('img');
            y.textContent = data[i].name;
            z.textContent = data[i].price;
            v.src = data[i].img;
            x.appendChild(y);
            x.appendChild(z);
            x.appendChild(v);
        }
    }
    function addProduct() {
        var request = new XMLHttpRequest();

        request.open('GET', 'products.json', true);

        request.onload = function () {
            // begin accessing JSON data here
            var data = JSON.parse(this.response);
            
            var name = document.getElementById("pname").value;
            var price = document.getElementById("price").value;
            var img = document.getElementById("img").value;
            data.push({"name": name, "price":price, "img": img});
            showProducts(data);
            
        }
        request.send();
    }